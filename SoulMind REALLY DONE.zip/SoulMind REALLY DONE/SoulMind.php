<?php
session_start();

 if(!isset($_SESSION["loggedin"]) ) {
    header("location: login.php");
    exit;
} 
?>
<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="UTF-8">
        <title > SoulMind </title>
        <h1 style="font-size:70px; text-align: center ;font-family:Century Gothic ;color : #ffffff" ><b > SoulMind </b></h1>
        <div class="topnav">
            <a class="active" href="#home">Home</a>
            <a href="#news">News</a>
            <a href="#contact">Contact</a>
            <a href="#about">About</a>
        </div>
    </head>
    <body>
        <img src="selflovejuice.jpg" alt="selflovejuice" style="width:200px;height:200px;">
        <h2 style="font-size:22px;font-family:Century Gothic ;color: #ff6edd;background-color:#F0F0F0"   ><b >What is Self-Care?</b></h2>
        Self-care is important to maintaining a healthy relationship with yourself. It means doing things to take care of our minds, bodies, 
        and souls by engaging in activities that promote well-being and reduce stress. Doing so enhances our ability to live fully, vibrantly, 
        and effectively. The practice of self-care also reminds both you and others that your needs are valid and a priority.
        <h3 style="font-size:22px;font-family:Century Gothic ;color: #ff6edd;background-color:#F0F0F0"><b >EXAMPLES OF SELF-CARE</b></h3>
        <ul>
            <li>Clean</li>
            <li>Cook or bake</li>
            <li>Cross something off your to-do list</li>
            <li>Exercise</li>
            <li>Get a massage</li>
            <li>Go for a walk</li>
            <li>Listen to music or a podcast</li>
            <li>Make art</li>
            <li>Meditation</li>
            <li>Mindfulness exercises</li>
            <li>Play a game</li>
            <li>Practice deep breathing</li>
            <li>Read</li>
            <li>Take a bath</li>
            <li>Take a (timed) nap</li>
            <li>Watch TV or a movie</li>
            <li>Yoga</li>
            
        </ul>
        <h4 style="font-size:22px;font-family:Century Gothic ;color: #ff6edd;background-color:#F0F0F0"><b >TYPES OF SELF-CARE</b></h4>
        <ul>
            <li style="font-size:30px; font-family:Century Gothic ;color: #ffffff ">MeTime </li>
            <img src="metime.jpeg" alt="metime" style="width:200px;height:250px;">
            <p>
                <a href="MeTime.html">Read More</a><br>
            </p>
            
            <li style="font-size:30px; font-family:Century Gothic ;color: #ffffff ">WeTime</li>
            <img src="wetime.jpg" alt="wetime" style="width:200px;height:250px;">
            <p>
                <a href="WeTime.html">Read More</a><br>
            </p>
            <li style="font-size:30px; font-family:Century Gothic ;color: #ffffff ">ZzzTime</li>
            <img src="zzztime.jpg" alt="zzztime" style="width:200px;height:200px;">
            <p>
                <a href="ZzzTime.html">Read More</a><br>
            </p>
            <li style="font-size:30px; font-family:Century Gothic ;color: #ffffff ">FlexTime</li>
            <img src="flex.png" alt="flextime" style="width:200px;height:200px;">
            <p>
                <a href="FlexTime.html">Read More</a><br>
            </p>
            <li style="font-size:30px; font-family:Century Gothic ;color: #ffffff ">TreeTime</li>
            <img src="treetime.jpg" alt="treetime" style="width:200px;height:200px;">
            <p>
                <a href="TreeTime.html">Read More</a><br>
            </p>
            <li style="font-size:30px; font-family:Century Gothic ;color: #ffffff ">PetTime</li>
            <img src="selfcaredog.jpg" alt="selfcaredog" style="width:200px;height:200px;">
            <p>
                <a href="PetTime.html">Read More</a><br>
            </p>
            
            <li style="font-size:30px; font-family:Century Gothic ;color: #ffffff ">ArtTime</li>
            <img src="arttime.jpg" alt="arttime" style="width:200px;height:200px;">
            <p>
                <a href="ArtTime.html">Read More</a><br>
            </p>
            <li style="font-size:30px; font-family:Century Gothic ;color: #ffffff ">ChowTime</li>
            <img src="chowtime.jpg" alt="chowtime" style="width:250px;height:200px;">
            <p>
                <a href="ChowTime.html">Read More</a><br>
            </p>
            <li style="font-size:30px; font-family:Century Gothic ;color: #ffffff ">ZenTime</li>
            <img src="zentime.jpg" alt="zentime" style="width:300px;height:200px;">
            <p>
                <a href="ZenTime.html">Read More</a><br>
            </p>
        </ul>
    </body>
    <style>
        .center {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 50%;
        }
        body{
            background-image: url('https://i.pinimg.com/originals/fe/0a/6a/fe0a6a4ee0627805864311f10f962c00.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
        }
        ul {
        list-style-type: circle;
        }
        ul li::before {
        content: "\2022";  /* Add content: \2022 is the CSS Code/unicode for a bullet */
        color: rgb(123, 0, 255); /* Change the color */
        font-weight: bold; /* If you want it to be bold */
        display: inline-block; /* Needed to add space between the bullet and the text */
        width: 1em; /* Also needed for space (tweak if needed) */
        margin-left: -1em; /* Also needed for space (tweak if needed) */
        }

        .topnav {
            background-color: #333;
            overflow: hidden;
          }
          
          /* Style the links inside the navigation bar */
          .topnav a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
          }
          
          /* Change the color of links on hover */
          .topnav a:hover {
            background-color: #ddd;
            color: black;
          }
          
          /* Add a color to the active/current link */
          .topnav a.active {
            background-color: #aa047e;
            color: white;
          }
    </style>
</html>
